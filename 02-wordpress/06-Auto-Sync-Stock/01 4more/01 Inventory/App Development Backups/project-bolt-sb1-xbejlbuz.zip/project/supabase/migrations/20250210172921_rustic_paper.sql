/*
  # Create products table and storage

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `price` (decimal)
      - `currency` (text)
      - `country` (text)
      - `image_url` (text)
      - `high_res_images` (text[])
      - `created_at` (timestamp)
      - `ocr_text` (text)
      
  2. Security
    - Enable RLS on `products` table
    - Add policies for authenticated users to read and insert data
*/

-- Create the products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal,
  currency text,
  country text,
  image_url text,
  high_res_images text[],
  created_at timestamptz DEFAULT now(),
  ocr_text text
);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access"
  ON products
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow authenticated insert"
  ON products
  FOR INSERT
  TO authenticated
  WITH CHECK (true);