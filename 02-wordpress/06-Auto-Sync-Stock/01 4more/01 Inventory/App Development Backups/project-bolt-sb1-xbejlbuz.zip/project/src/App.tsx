import React, { useState } from 'react';
import { ImageCapture } from './components/ImageCapture';
import { createWorker } from 'tesseract.js';
import { supabase } from './lib/supabase';
import { Loader2 } from 'lucide-react';

interface ProductInfo {
  name: string;
  description: string;
  price: number;
  currency: string;
  country: string;
  imageUrl: string;
  highResImages: string[];
  ocrText: string;
}

function App() {
  const [loading, setLoading] = useState(false);
  const [productInfo, setProductInfo] = useState<ProductInfo | null>(null);

  const processImage = async (imageData: string) => {
    setLoading(true);
    try {
      // Perform OCR
      const worker = await createWorker();
      await worker.loadLanguage('eng');
      await worker.initialize('eng');
      const { data: { text } } = await worker.recognize(imageData);
      await worker.terminate();

      // For demo purposes, we'll simulate product info retrieval
      // In a real app, you would call your product search API here
      const mockProductInfo: ProductInfo = {
        name: "Sample Product",
        description: "This is a sample product description based on the image analysis.",
        price: 99.99,
        currency: "USD",
        country: "United States",
        imageUrl: imageData,
        highResImages: [
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
          "https://images.unsplash.com/photo-1572635196237-14b3f281503f"
        ],
        ocrText: text
      };

      // Save to Supabase
      const { error } = await supabase
        .from('products')
        .insert([{
          name: mockProductInfo.name,
          description: mockProductInfo.description,
          price: mockProductInfo.price,
          currency: mockProductInfo.currency,
          country: mockProductInfo.country,
          image_url: mockProductInfo.imageUrl,
          high_res_images: mockProductInfo.highResImages,
          ocr_text: mockProductInfo.ocrText
        }]);

      if (error) throw error;

      setProductInfo(mockProductInfo);
    } catch (error) {
      console.error('Error processing image:', error);
      alert('Error processing image. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">
          Product Image Analyzer
        </h1>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <ImageCapture onImageCapture={processImage} />
        </div>

        {loading && (
          <div className="flex items-center justify-center gap-2 text-gray-600">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span>Processing image...</span>
          </div>
        )}

        {productInfo && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-4">{productInfo.name}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <img
                  src={productInfo.imageUrl}
                  alt="Uploaded product"
                  className="w-full rounded-lg mb-4"
                />
                <div className="space-y-2">
                  <p><strong>Price:</strong> {productInfo.price} {productInfo.currency}</p>
                  <p><strong>Country:</strong> {productInfo.country}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Description</h3>
                  <p className="text-gray-600">{productInfo.description}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">OCR Text</h3>
                  <p className="text-gray-600 text-sm">{productInfo.ocrText}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">High Resolution Images</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {productInfo.highResImages.map((url, index) => (
                      <img
                        key={index}
                        src={url}
                        alt={`Product view ${index + 1}`}
                        className="w-full rounded-lg"
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;