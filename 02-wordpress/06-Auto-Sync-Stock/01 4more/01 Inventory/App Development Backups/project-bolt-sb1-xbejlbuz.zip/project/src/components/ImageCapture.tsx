import React, { useRef, useState } from 'react';
import Webcam from 'react-webcam';
import { Camera, Upload, X } from 'lucide-react';

interface ImageCaptureProps {
  onImageCapture: (imageData: string) => void;
}

export const ImageCapture: React.FC<ImageCaptureProps> = ({ onImageCapture }) => {
  const [showCamera, setShowCamera] = useState(false);
  const webcamRef = useRef<Webcam>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const captureImage = React.useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      onImageCapture(imageSrc);
      setShowCamera(false);
    }
  }, [webcamRef, onImageCapture]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageCapture(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {showCamera ? (
        <div className="relative">
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            className="w-full rounded-lg"
          />
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
            <button
              onClick={captureImage}
              className="bg-blue-500 text-white p-2 rounded-full hover:bg-blue-600"
            >
              <Camera className="w-6 h-6" />
            </button>
            <button
              onClick={() => setShowCamera(false)}
              className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <button
            onClick={() => setShowCamera(true)}
            className="flex items-center justify-center gap-2 bg-blue-500 text-white p-3 rounded-lg hover:bg-blue-600"
          >
            <Camera className="w-5 h-5" />
            Take Picture
          </button>
          <input
            type="file"
            accept="image/*"
            className="hidden"
            ref={fileInputRef}
            onChange={handleFileUpload}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center justify-center gap-2 bg-gray-500 text-white p-3 rounded-lg hover:bg-gray-600"
          >
            <Upload className="w-5 h-5" />
            Upload Image
          </button>
        </div>
      )}
    </div>
  );
};